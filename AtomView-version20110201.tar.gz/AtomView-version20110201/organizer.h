/*
  organizer.h
  by Wei Cai  caiwei@mit.edu
  Last Modified : Thu Oct  6 11:37:59 2005

  FUNCTION  : Organizer package to facilitate MD simulation

  Featuring : class Oragnizer, class AUXFile
*/

#ifndef _ORGANIZER_H
#define _ORGANIZER_H

#include "scparser.h"
#include "filecls.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>

class AUXFile
{
public:
    LFile *f; int type; int count; char fname[1000], extname[1000];
    virtual int writeentry(void *){return 0;}
    virtual int writeblock(void *){return 0;}
    virtual int readblock(void *){return 0;}
    virtual char *describe(){return 0;}
public:
    enum {ENTRIES,BLOCK,SERIES};
    AUXFile(int t):f(NULL),type(t),count(1){};
    virtual ~AUXFile(){close();}
    int close(int zip=1, bool bg=true);
    int open(char *name,int format=LFile::O_WriteNew);
    int reopen();
    int write(void *p, int zip=1, bool bg=true);
    int read(void *p);
    static const char *Skip(const char *str, const char *blank)
    {
        ASSERT(str!=NULL);
        ASSERT(blank!=NULL);
        const char *ret=str;
        while(*ret!=0 && strchr(blank, *ret)) ret++;
        return ret;
    }
    static const char *SkipBlanks(const char *str)
        { return Skip(str, " \n\t\r"); }

    void setcount(int n){count=n;}
private:
    int lastoccur(char *n,char c);        
    void insertindex(char *ext,char *n,int c);
};


class Organizer : private SCParser
{
public:
    bool overwrite,nolog,renew;
    int sleepseconds;
    LFile *olog;
public:
    char dirname[1000], logfilename[1000];
public:
    Organizer():overwrite(false),nolog(false),renew(false),
        sleepseconds(600),olog(NULL){init();};
    virtual ~Organizer() {} //{closefiles();}

    void bindvar(char *vn,void *p,int type)
        {SCParser::bindvar(vn,p,type);}
    int exec(char *name);
    int parse(FILE *file);
    int assignvar(int offset=0);
    
private:
    void setoverwrite(bool b=true){overwrite=b;}
    void setnolog(bool b=true){nolog=b;}
    void quit();
    void getsleep();
    void init(); //system use
    int SysParse(FILE *file); //system use
    char *currentime();
    void printSysInfo();
    void printEndInfo();
    void closefiles(int zip=1,bool bg=true);
    int opendir();
};

#define ah HIC"ASSIGN "NOR
#define eh HIB"EXEC   "NOR

#define INFO_buffer_plain(pre,ref,type) INFO(pre<<varname[curn] \
                                       <<" = "\
                                       <<ref((type *)varptr[curn]))
#define INFO_buffer_offset(pre,ref,type) INFO(pre<<varname[curn] \
                                       <<"("<<offset<<") = "\
                                       <<ref(((type *)varptr[curn])+offset))
#define INFO_buffer(pre,ref,type) if(offset==0) \
                                       INFO_buffer_plain(pre,ref,type);\
                                  else INFO_buffer_offset(pre,ref,type);

#endif // _ORGANIZER_H

