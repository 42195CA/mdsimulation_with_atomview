/*
  md.h
  by Wei Cai  caiwei@stanford.edu
  Last Modified : Thu Sep 29 18:12:07 2005

  FUNCTION  :  Easy-to-use MD simulation Framefork

  Featuring :  1. Scripting input
               2. X-window display
               3. automatic simulation log
               4. convenient configuration and output file handle
               5. perfect lattice and dislocation config creator
               6. conjugate-gradient relaxation
               7. NVT MD simulation
               8. Cell-Verlist combined neighbor list
               
  This is a single CPU code.
  Previous shared-memory option removed.
  May implment MPI parallelization in the future.
*/


#ifndef _ATOMVIEW_H
#define _ATOMVIEW_H



#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "general.h"
#include "organizer.h"
#include "display.h"
#include "linalg3.h"
#include <iostream>
#include <fstream>
using namespace std;

/* Internal units
   Energy:  eV
   Length:  A
   Stress:  eV/A^3

   Stored Internal Variables
   Position:     r               (in A)
   Velocity:     v*TIMESTEP      (in A)
   Accelaration: a*TIMESTEP^2/2  (in A)
*/

/* Physical constants */
#define AVO  6.0221367E+23
#define EV   1.6021772E-19     /* (J)    */
#define BOLZ 1.380658E-23      /* (J/K)  */
#define KB   0.8617336E-4      /* (eV/K) */
#ifndef max
#define max(a,b) (((a)>(b))?(a):(b))
#endif
#ifndef min
#define min(a,b) (((a)<(b))?(a):(b))
#endif

#define MAXSPECIES 10          /* maximum number of species */
#define MAXCOLORS  10          /* maximum number of colors in display */
#define MAXCONSTRAINATOMS 1001 /* maximum number of atoms in constrained minimization */

/* Random number generator for platforms not supporting drand48 (e.g. cygwin) */
#ifdef _ODRAND48
#define drand48 (1.0/RAND_MAX)*rand
#endif

#define MP_Sync() {}
#define MP_BeginMasterOnly() {}
#define MP_EndMasterOnly() {}
#define MP_Free(s) free(s)
#define MP_cpu() 0
#define MP_ncpu() 1

#define Realloc(p,t,s) {p=(t *)realloc(p,sizeof(t)*s);}
#define bindcommand_sync bindcommand



/* Input/output files */
class CNFile : public AUXFile /* configuration(cn) file */
{
public:
    CNFile(int t):AUXFile(t){};
    virtual char * describe();
private:
    virtual int writeblock(void *p);
    virtual int readblock(void *p);
};


/* MD simulation framework */
class MDFrame : public Organizer
{
public:
    int _SAVEMEMORY;    /* controls how much memory is allocated per atom */
    int _NP;            /* total number of atoms */

    class Vector3 *_R, *_SR;   /* real and scaled coordinates of atoms */
    class Vector3 *_VR, *_VSR; /* real and scaled velocities of atoms */
    class Vector3 *_F;         /* force on atoms */
    class Vector3 *_R0;        /* place to save old coordinates of atoms */
    class Vector3 *_Fext;      /* external force on atoms */

    int *fixed;                /* 1 if atom is fixed */
    int *group;                /* top 1, bottom 2, middle 0 */
    int *image;                /* image atom */
    int *species;              /* species type of atom */    
    int nspecies;              /* number of atom species */
    char element[MAXSPECIES][10]; /* species names */
    int applysurfaceexternalstress;  /*if apply surface external stress, then 1*/

    class Matrix33 _H, _H0;     /* simulation box vectors and copy */
    class Matrix33 _VIRIAL, _VH;/* Virial stress, and velocity of H */
    double _EPOT, *_EPOT_IND, *_EPOT_IND2;   /* total potential energy and contribution per atom */
    double _EPOT0;              /* potential energy from previous step */
    double *_TOPOL;             /* atomic environment, e.g. central symmetry parameter */

    /* Molecular Dynamics parameters */
    double _ESTRAIN;             /* box strain energy (in eV) */
    double _KATOM, _KBOX;        /* kinetic energies (in eV) */
    double _ATOMMASS, _WALLMASS; /* in (g/mol) */
    double _TIMESTEP;            /* in picosecond (ps) */
    double _TDES,_T;             /* desired and current temperature */
    int _DOUBLET;                /* 1: if initialize T double desired temperature */
    double _ATOMTCPL,_BOXTCPL;   /* temperature coupling constants */

     double *nnn;
     int *nn;                    /* nn[i]: number of neighbors of atom i */
     int **nindex;               /* nindex[i][j]: the jth neighbor of atom i */


    /* Configuration manipulation */
    class Vector3 *storedr;         /* atomic displacements */
    class Matrix33 dH;              /* change of matrix H (cell size) */
    char  crystalstructure[30];     /* crystal structure for makecrystal() */
    double latticeconst[3];         /* lattice constant  for makecrystal() */
    double latticesize[3][4];       /* lattice size for makecrystal() */

    
    /* File input and output */
    double input[2000];                     /* general input variable in script file */
    class CNFile initcn,intercn,finalcn;    /* configuration file objects */
    char incnfile[200], finalcnfile[200];   /* configuration file name */
    char intercnfile[200];                  /* configuration file name */
    char outpropfile[200];                  /* property file name */
    char myname[200];                       /* name of the simulation */
    char potfile[100];                      /* name of potential file */    
    char command[1000]; int ncom;           /* shell command */
    int  savecn, savecnfreq;                /* frequency of saving cn files */
    int  saveprop, savepropfreq;            /* frequency of saving prop files */
    int  printfreq;                         /* frequency of printing on scren */
    int  filecounter;                       /* number of current file */
    int allocmultiple;                      /* allocate more memory than current number of atoms */
    int writevelocity;                      /* write velocity into cn file */
    int writeall;                           /* write "sx,sy,sz,vx,vy,vz,pot,fixed" into cn file */
    int fixedatomenergypartition;           /* 1: disregard energy contribution from fixed atoms */    


        
    /* Visualization */
    YWindow *win;                   /* Display window object */

    int win_width, win_height;      /* size of the window */
    double rotateangles[4];         /* rotation angles and scaling parameter */
    int plotfreq;                   /* frequency of re-plotting */
    double atomradius[MAXSPECIES];  /* size of atoms */
    double bondradius, bondlength;  /* thickness and length of bonds */

    char atomcolor[MAXSPECIES][30]; /* color of atom species */
    char bondcolor[30];             /* color of bonds */    
    char fixatomcolor[30];          /* color of fixed atoms, fixed[i]=1 */
    char highlightcolor[30];        /* color of highlighted atoms */
    char backgroundcolor[30];       /* background color of window */
    char colornames[MAXCOLORS][30]; /* names of allocated colors */
    unsigned colors[MAXCOLORS+15];  /* value of allocated colors */

    int plot_highlight_atoms[10000];/* indices of atoms to be highlighed */    
    double plot_limits[10];         /* set x,y,z, limits of plotting regime */
    int    plot_atom_info;           /* print information when atom is clicked */
    double plot_color_windows[100]; /* only plot atoms whose properties fall into specified windows */
    double plot_color_bar[10];      /* how to color atoms according to their properties */
    int    plot_color_axis;          /* which atomic property specifies color */

    double plot_defect_windows[100]; /* only plot atoms who are defect atoms */

    int autowritegiffreq;           /* frequency of outputing .GIF graphics file */
    double *color_ind,*ccolor_ind;              /* property linked to atom color */
    int NCS;                        /* number of neighbors for central symmetry parameter comp. */

    int plotDisp; /*if plot the arrow to indicate the displacement from the first inter.cn*/

    int writedefect; /*if write defect position into external file*/
    char defectcnfile[200];   /* defect file for 3D gnuplot */
    
    /* Constructor (set initial values of member variables) */
    MDFrame(): _SAVEMEMORY(0),_NP(0),

               _R(0),_SR(0),_VR(0),_VSR(0),_F(0),_R0(0),_Fext(0),

               fixed(0),species(0),nspecies(1),
               _EPOT(0),_EPOT_IND(0),_EPOT0(0),_TOPOL(0),

               /* Molecular Dynamics parameters */
               _ESTRAIN(0),_KATOM(0),_KBOX(0),_ATOMMASS(1),_WALLMASS(1),
               _TIMESTEP(1e-3),_TDES(0),_T(0),_DOUBLET(0),
               _ATOMTCPL(100),_BOXTCPL(100),
  
                /* File input and output */
               initcn(AUXFile::BLOCK),intercn(AUXFile::SERIES),
               finalcn(AUXFile::BLOCK),
               ncom(0),savecn(0),savecnfreq(100),saveprop(0),savepropfreq(100),
               printfreq(100),filecounter(1),allocmultiple(1),
               writevelocity(0),writeall(0),fixedatomenergypartition(0),plotDisp(0),

               /* Visualization */
               win(0),win_width(350),win_height(350),
               plotfreq(1),bondradius(0.1),bondlength(0),plot_atom_info(1),
               plot_color_axis(0),autowritegiffreq(0),color_ind(0),NCS(12),
               writedefect(1)
      
               
    {
        /* Input/output control */
        input[0]=0;
        
        /* Configuration manipulation */
        latticeconst[0]=latticeconst[1]=latticeconst[2]=1.0;
        sprintf(crystalstructure,"simple-cubic");

        /* Plot settings */
        plot_highlight_atoms[0]=0;
        plot_limits[0]=0;
        plot_color_windows[0]=0;
        plot_color_bar[0]=0;
     
    };

    virtual ~MDFrame() { delete(win);}
            
    /* Parser */    
    virtual void initparser();
    virtual int exec(char *name);            
    virtual void initvars();
     /* Coordinate transformation */
    void SHtoR();
    void RHtoS();
    void RtoR0();
    void R0toR();
    void SR0toR0();
    bool Bond(int I, int J) const;
    
    virtual void Alloc();

    /* File input and output */
    int readcn();
    void outps();  /*output to ps file*/
    void outgif();  /*output to gif file*/
    void makeanigif(); /*make animation gif files*/
 
   /* Visualization */
    virtual void winplot();        
    virtual void winplot(int);
    virtual void openwin();
    virtual void plot();
    int     openwindow(int w,int h,const char *n);
    void    closewindow();
    void    wintogglepause();
    void    alloccolors();
    void    alloccolorsX();
    void    rotate();
    void    saverot();
};    


#endif //_ATOMVIEW_H
