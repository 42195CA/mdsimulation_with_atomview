
#include "atomview.h"

/********************************************************************/
/* Initialize script file parser */
/********************************************************************/
void MDFrame::initparser()
{
	char s[100];

	/* Parser */
	bindvar("myname",myname,STRING);
	bindvar("command",command,STRING);
	bindvar("input",input,DOUBLE);
    
	/* Molecular Dynamics */
	bindvar("SAVEMEMORY",&_SAVEMEMORY,INT);    
	bindvar("nspecies",&nspecies,INT);
	bindvar("atommass",&_ATOMMASS,DOUBLE);
	bindvar("allocmultiple",&allocmultiple,INT);
	

	/* Configuration manipulation */
	bindvar("crystalstructure",crystalstructure,STRING);
	bindvar("latticeconst",latticeconst,DOUBLE);
	bindvar("latticesize",latticesize,DOUBLE);
    
	bindvar("latticestructure",crystalstructure,STRING);/* for backward compatibility */
	bindvar("makecnspec",latticesize,DOUBLE);/* for backward compatibility */
	
	/* File input and output */
	bindvar("incnfile",incnfile,STRING);

	/* Visualization */
	bindvar("win_width",&win_width,INT);
	bindvar("win_height",&win_height,INT);
	bindvar("plotfreq",&plotfreq,INT);
	bindvar("atomradius",atomradius,DOUBLE);
	bindvar("bondradius",&bondradius,DOUBLE);
	bindvar("bondlength",&bondlength,DOUBLE);
	bindvar("bondcolor",bondcolor,STRING);
	bindvar("highlightcolor",highlightcolor,STRING);
	bindvar("fixatomcolor",fixatomcolor,STRING);
	bindvar("backgroundcolor",backgroundcolor,STRING);
	bindvar("rotateangles",rotateangles,DOUBLE);

	bindvar("plot_limits",plot_limits,DOUBLE);
	bindvar("plot_atom_info",&plot_atom_info,INT);
	bindvar("plot_color_windows",plot_color_windows,DOUBLE);
	bindvar("plot_color_bar",plot_color_bar,DOUBLE);
	bindvar("energycolorbar",plot_color_bar,DOUBLE); /* for backward compatibility */

	bindvar("plot_defect_windows",plot_defect_windows,DOUBLE);
	bindvar("plot_color_axis",&plot_color_axis,INT);
	bindvar("NCS",&NCS,INT);
	bindvar("autowritegiffreq",&autowritegiffreq,INT);
	bindvar("plotDisp",&plotDisp,INT);

	

	for(int i=0;i<MAXSPECIES;i++)
	{
		sprintf(s,"element%d",i);
		bindvar(s,element[i],STRING);
		sprintf(s,"atomcolor%d",i);
		bindvar(s,atomcolor[i],STRING);
	}
	bindvar("atomcolor",atomcolor[0],STRING);
	for(int i=0;i<MAXCOLORS;i++)
	{
		sprintf(s,"color%02d",i);
		bindvar(s,colornames[i],STRING);
	}
}    

int MDFrame::exec(char *name)
{
	if(Organizer::exec(name)==0) return 0;

	/* File input and output */
	bindcommand(name,"readcn",readcn());
	bindcommand(name,"outps",outps());
	bindcommand(name,"outgif",outgif());	
	bindcommand(name,"makeanigif",makeanigif());	
	
	/* Visualization */
	bindcommand(name,"openwin",openwin());
	bindcommand(name,"plot",plot());
	bindcommand(name,"alloccolors",alloccolors());
	bindcommand(name,"alloccolorsX",alloccolorsX());
	bindcommand(name,"testcolor",win->testcolor());
	bindcommand(name,"reversergb",win->reversergb());
	bindcommand(name,"rotate",rotate());
	bindcommand(name,"saverot",saverot());
	bindcommand(name,"wintogglepause",wintogglepause());

	return -1;
}

void MDFrame::initvars()
{
	initparser();
	strcpy(command,"echo Hello World");
    
	strcpy(incnfile,"con.cn");
	strcpy(intercnfile,"inter.cn");
	strcpy(finalcnfile,"final.cn");
	strcpy(potfile,"../Mo.pot");

    
    
	strcpy(outpropfile,"prop.out");
#ifdef _CALPHONONSPECTRUM
	strcpy(phonondispfile,"dispersion.m");
#endif
    
	strcpy(bondcolor,"red");
	strcpy(highlightcolor,"purple");

	for(int i=0;i<MAXSPECIES;i++)
	{
		atomradius[i]=0.1;
		strcpy(atomcolor[i],"orange");
		strcpy(element[i],"Mo");
	}
	for(int i=0;i<MAXCOLORS;i++)
	{
		strcpy(colornames[i],"gray50");
	}


	strcpy(element[1],"Mo");
	strcpy(element[2],"Si");
	strcpy(element[3],"Cu");
	strcpy(element[4],"Zr");
}





void MDFrame::SHtoR()
{ for(int i=0;i<_NP;i++) _R[i]=_H*_SR[i]; }
void MDFrame::RHtoS()
{ Matrix33 hinv=_H.inv();
 for(int i=0;i<_NP;i++) _SR[i]=hinv*_R[i]; }
void MDFrame::RtoR0()
{ int i; SHtoR(); for(i=0;i<_NP;i++) _R0[i]=_R[i]; }
void MDFrame::R0toR()
{ int i; for(i=0;i<_NP;i++) _R[i]=_R0[i]; }

void MDFrame::SR0toR0()
{ int i; for(i=0;i<_NP;i++) _R0[i]=_H*_R0[i];}


bool MDFrame::Bond(int I, int J) const
{/* Returns true if bond(i,j) is stored in I */
	return (I<=J)? ((I^J)&1)  : !((I^J)&1);
}

/* Memory Allocation */
void MDFrame::Alloc()
{
	int size;
	size=_NP*allocmultiple;
    
	/* Shared Memory */
	Realloc(_SR,Vector3,size);
	Realloc(fixed,int,size);
	memset(fixed,0,sizeof(int)*size);
	Realloc(group,int,size);
	memset(group,0,sizeof(int)*size);

	
	
	if(_SAVEMEMORY>=9) return;
	/* The following is only allocated if _SAVEMEMORY < 9 */

	Realloc(nnn,double,size);
	memset(nnn,0,sizeof(double)*size);

	Realloc(_R,Vector3,size);
	Realloc(_R0,Vector3,size);
	Realloc(image,int,size);
	Realloc(species,int,size);
	Realloc(_TOPOL,double,size);
	memset(image,0,sizeof(int)*size);
	memset(species,0,sizeof(int)*size);
	memset(_TOPOL,0,sizeof(double)*size);
	if(_SAVEMEMORY>=1) return;
	/* The following is only allocated if _SAVEMEMORY < 1 */
    
	Realloc(_VR,Vector3,size);
	Realloc(_VSR,Vector3,size);
	Realloc(_F,Vector3,size);
	Realloc(_Fext,Vector3,size);
	Realloc(_EPOT_IND,double,size);
	memset(_EPOT_IND,0,sizeof(double)*size);
	
	Realloc(_EPOT_IND2,double,size);
	memset(_EPOT_IND2,0,sizeof(double)*size);


}


int MDFrame::readcn()
{
	initcn.open(incnfile,LFile::O_Read);
	return initcn.read(this);
}

void MDFrame::outps()
{
	if(win!=NULL) win->writeps();
}

void MDFrame::outgif()
{
	if(win!=NULL) win->importgif(); 
}
						
void MDFrame::makeanigif()
{
	/*
	 * input = [intercnBegin  intercnEnd  gifBegin deltaCN]
	 * readcn from intercnBegin to intercnEnd each deltaCN;
	 * write gif file with number from gifBegin;
	 */
	int inter0,inter1,delcn;//,gifstartnum;
	inter0 = (int)input[0];
	inter1 = (int)input[1];
//	gifstartnum = (int)input[2];
	win->gifcount = (int)input[2];
	delcn = (int)input[3];

	const char prefname[]="inter";
	const char posfname[]=".cn";
	char extname[200],tmp[100];
  	
	for(int i=inter0;i<=inter1;i=i+delcn)
//	for(int i=inter0;i<=inter1;i++)	
	{
		sprintf(tmp,"%04d",i);
		strcpy(incnfile,prefname);
		strcat(incnfile,tmp);
		strcat(incnfile,posfname);
//		incnfile = extname;
		readcn();
		if(win!=NULL)
		{
			plot();
			win->importgif();
		}
	}

	
}

/* Configuration Files */
char * CNFile::describe()
{
	static char tmp[500];
	sprintf(tmp,"%s","Configuration File for Atom Positions, Format:\n"
		"sx1 sy1 sz1; ... ; sxn syn szn; H(3x3)");
	return tmp;
}

int CNFile::writeblock(void *p)
{
	int i;
	MDFrame &d=*((MDFrame *)p);
	f->Printf("%d\n",d._NP);
	for(i=0;i<d._NP;i++)
	{
		if (d.writeall)
			f->Printf("%25.17E %25.17E %25.17E %25.17E %25.17E %25.17E"
				  " %25.17E %2d %25.17E %2d\n",
				  d._SR[i].x,d._SR[i].y,d._SR[i].z,
				  d._VSR[i].x,d._VSR[i].y,d._VSR[i].z,
				  d._EPOT_IND[i],d.fixed[i],d._TOPOL[i],d.species[i]);
		else if (d.writevelocity)
			f->Printf("%25.17E %25.17E %25.17E %25.17E %25.17E %25.17E\n",
				  d._SR[i].x,d._SR[i].y,d._SR[i].z,
				  d._VSR[i].x,d._VSR[i].y,d._VSR[i].z);
		else
			f->Printf("%25.17E %25.17E %25.17E\n",
				  d._SR[i].x,d._SR[i].y,d._SR[i].z);
	}
	f->Printf("%25.17E %25.17E %25.17E\n"
		  "%25.17E %25.17E %25.17E\n"
		  "%25.17E %25.17E %25.17E\n",
		  d._H[0][0],d._H[0][1],d._H[0][2],
		  d._H[1][0],d._H[1][1],d._H[1][2],
		  d._H[2][0],d._H[2][1],d._H[2][2]);
	f->Printf("%d ",d.nspecies);
	for(i=0;i<d.nspecies;i++) f->Printf("%s ",d.element[i]);
	f->Printf("\n");
	return 0;
}



int CNFile::readblock(void *p)
{
	int i;
	char *buffer, *pp, *q;
	MDFrame &d=*((MDFrame *)p);
    
	LFile::LoadToString(fname,buffer,0);

	pp=buffer;
	sscanf(pp, "%d", &d._NP);
	sscanf(pp, "%d", &d._NP);	
	INFO("readblock: NP="<<d._NP);    
    
	if(d.plotDisp==0)	d.Alloc();
    
	pp=strchr(pp, '\n');
	pp++;
	for(i=0;i<d._NP;i++)
	{
		q=pp;
		pp=strchr(pp,'\n');
		if(pp) *(char *)pp++=0;
		d._VSR[i].clear();
		d.fixed[i]=0;
//liu v		sscanf(q, "%lf %lf %lf %lf %lf %lf %lf %d %lf %d",
// 		       &(d._SR[i].x),&(d._SR[i].y),&(d._SR[i].z),
// 		       &(d._VSR[i].x),&(d._VSR[i].y),&(d._VSR[i].z),
// 		       &(d._EPOT_IND[i]),&(d.fixed[i]),&(d._TOPOL[i]),&(d.species[i]));

		if(d.plotDisp==0)
			sscanf(q, "%lf %lf %lf %lf %lf %lf %lf %d %lf %d",
 		       &(d._SR[i].x),&(d._SR[i].y),&(d._SR[i].z),
 		       &(d._VSR[i].x),&(d._VSR[i].y),&(d._VSR[i].z),
 		       &(d._EPOT_IND[i]),&(d.nnn[i]),&(d._TOPOL[i]),&(d.species[i]));
		else
			sscanf(q, "%lf %lf %lf %lf %lf %lf %lf %d %lf %d",
 		       &(d._R0[i].x),&(d._R0[i].y),&(d._R0[i].z),
 		       &(d._VSR[i].x),&(d._VSR[i].y),&(d._VSR[i].z),
		       &(d._EPOT_IND2[i]),&(d.nnn[i]),&(d.nnn[i]),&(d.species[i]));


//        d.fixed[i]=0;
//		if(d._TOPOL[i]>0)        INFO_Printf("_TOPOL[%d]=%d\n",i,d._TOPOL[i]);
	}

	if(d.plotDisp==0)
	{
//    INFO_Printf("reading H...\n");
		q=pp; pp=strchr(pp,'\n'); if(pp) *(char *)pp++=0;
		sscanf(q, "%lf %lf %lf",&d._H[0][0],&d._H[0][1],&d._H[0][2]);
		q=pp; pp=strchr(pp,'\n'); if(pp) *(char *)pp++=0;
		sscanf(q, "%lf %lf %lf",&d._H[1][0],&d._H[1][1],&d._H[1][2]);
		q=pp; pp=strchr(pp,'\n'); if(pp) *(char *)pp++=0;
		sscanf(q, "%lf %lf %lf",&d._H[2][0],&d._H[2][1],&d._H[2][2]);

		q=pp; pp=strchr(pp,'\n'); if(pp) *(char *)pp++=0;
//    INFO_Printf("reading species...\n");
// 	sscanf(q, "%d %s %s %s %s %s %s %s %s %s %s",
// 	       &(d.nspecies),
// 	       d.element[0],d.element[1],d.element[2],d.element[3],d.element[4],
// 	       d.element[5],d.element[6],d.element[7],d.element[8],d.element[9]);
//    INFO_Printf("nspecies = %d %s %s\n",d.nspecies,d.element[0],d.element[1]);
		
	}
	Free(buffer);
	   if(d.plotDisp==0)
	   DUMP("readblock finished");
	   else
	   DUMP("read second block finished");
	   
	return 0;
}




/********************************************************************/
/* Visualization */
/********************************************************************/

void MDFrame::openwin()
{
	MP_BeginMasterOnly();
	openwindow(win_width,win_height,dirname);
	MP_EndMasterOnly();
}

int MDFrame::openwindow(int w,int h,const char *n)
{
	if(win!=NULL)
		if(win->alive) return -1;
	MP_BeginMasterOnly();
	win=new YWindow(w,h,n,true,true,false);
	MP_EndMasterOnly();
	if(win==NULL) return -1;
	else
	{
		MP_BeginMasterOnly();
		win->setinterval(100);
		win->Run();
		MP_EndMasterOnly();
		return 0;
	}
}

void MDFrame::closewindow() {delete(win);}

void MDFrame::winplot()
{
	MP_BeginMasterOnly();
	if(win!=NULL)
		if(win->alive) plot();
	MP_EndMasterOnly();
}

void MDFrame::winplot(int step)
{
	MP_BeginMasterOnly();
	if(win!=NULL)
		if(win->alive)
			if((step%plotfreq)==0)
			{
				plot();
// 				atomeye();
			}
	MP_EndMasterOnly();
}        

void MDFrame::wintogglepause()
{
	if(win!=NULL)
		if(win->IsAlive())
			win->TogglePause();
}

#include "namecolor.c"
void MDFrame::alloccolors()
{
	int r,g,b;
	MP_BeginMasterOnly();
	if(win!=NULL)
	{
		if(win->alive)
		{
			for(int i=0;i<MAXCOLORS;i++)
			{
				Str2RGB(colornames[i],&r,&g,&b);
				colors[i]=win->AllocShortRGBColor(r,g,b);
				win->displaycolors[i]=colors[i];
			}
            
			Str2RGB(atomcolor[0],&r,&g,&b);
			colors[MAXCOLORS+0]=win->AllocShortRGBColor(r,g,b);
			win->displaycolors[MAXCOLORS+0]=colors[MAXCOLORS+0];		
			Str2RGB(bondcolor,&r,&g,&b);
			colors[MAXCOLORS+1]=win->AllocShortRGBColor(r,g,b);
						win->displaycolors[MAXCOLORS+0]=colors[MAXCOLORS+0];		
			Str2RGB(highlightcolor,&r,&g,&b);
			colors[MAXCOLORS+2]=win->AllocShortRGBColor(r,g,b);
						win->displaycolors[MAXCOLORS+0]=colors[MAXCOLORS+0];		
			Str2RGB(fixatomcolor,&r,&g,&b);
			colors[MAXCOLORS+3]=win->AllocShortRGBColor(r,g,b);
						win->displaycolors[MAXCOLORS+0]=colors[MAXCOLORS+0];		
			Str2RGB(backgroundcolor,&r,&g,&b);
			win->bgcolor=win->AllocShortRGBColor(r,g,b);
			

			for(int i=0;i<MAXSPECIES;i++)
			{
				Str2RGB(atomcolor[i],&r,&g,&b);
				colors[MAXCOLORS+5+i]=win->AllocShortRGBColor(r,g,b);
							win->displaycolors[MAXCOLORS+5+i]=colors[MAXCOLORS+5+i];		
			}
		}
		else
		{
			WARNING("No window to allocate color for!");
		}
	}
	else
	{
		WARNING("No window to allocate color for!");
	}
	MP_EndMasterOnly();
}
void MDFrame::alloccolorsX()
{
	MP_BeginMasterOnly();
	if(win!=NULL)
	{
		if(win->alive)
		{
			colors[0]=win->AllocNamedColor(atomcolor[0]);
			colors[1]=win->AllocNamedColor(bondcolor);
			colors[2]=win->AllocNamedColor(highlightcolor);
			colors[3]=win->AllocNamedColor(fixatomcolor);
			win->bgcolor=win->AllocNamedColor(backgroundcolor);
		}
		else
		{
			WARNING("No window to allocate color for!");
		}
	}
	else
	{
		WARNING("No window to allocate color for!");
	}
	MP_EndMasterOnly();
}

void MDFrame::rotate()
{
	MP_BeginMasterOnly();
	if(win!=NULL)
	{
		if(win->alive)
		{
			win->horizontalRot(rotateangles[0]*M_PI/180);
			win->verticalRot(rotateangles[1]*M_PI/180);
			win->spinRot(rotateangles[2]*M_PI/180);
			if(rotateangles[3]!=0) win->zoom(rotateangles[3]);
		}
		else
		{
			WARNING("No window to rotate for!");
		}
	}
	else
	{
		WARNING("No window to rotate for!");
	}
	MP_EndMasterOnly();
}

void MDFrame::saverot()
{
	MP_BeginMasterOnly();
	if(win!=NULL)
	{
		if(win->alive)
		{
			win->saveRot(); win->saveScale();
		}
		else
		{
			WARNING("No window to rotate for!");
		}
	}
	else
	{
		WARNING("No window to rotate for!");
	}
	MP_EndMasterOnly();
}

#include "colormap.h"
#include <iostream>
using namespace std;

void MDFrame::plot()
{
	int i,jp,j,k;
	double L,r2;
	char s[500]; bool high;
	double x1,y1,z1,x2,y2,z2,dx,dy,dz,dr;
	int r,g,b; double alpha; unsigned ce;
	Vector3 s1, s2, vr1, vr2;
	int nw, cind, show; double Emin, Emax;

	double EEmax, EEmin;
	int kk,ccind;

	
	MP_BeginMasterOnly();

	if(win==NULL) return;
	if(!(win->alive)) return;
    
	L=max(_H[0][0],_H[1][1]);
	L=max(L,_H[2][2])*.5;

	
	switch(plot_color_axis){
	case(0):
	{
		if(plotDisp==0)
		{
			color_ind=_EPOT_IND; break;
		}
		else
		{
				color_ind=_EPOT_IND;
				ccolor_ind=_EPOT_IND2;
				break;
		}
		
	}
	case(2): color_ind=_TOPOL; break;
	case(3): color_ind=nnn; break;
	default: ERROR("plot() unknown coloraxis "<<plot_color_axis); return;
	}


	
	SHtoR();
	SR0toR0();
	win->Lock();
	win->Clear();

//	win->setBoxLen(L/3.249);
	win->setBoxLen(L/latticeconst[0]);
	
	/* draw atom s*/
	int totalplotatom=0;
	for(i=0;i<_NP;i++)
	{
		/* if plot_limits[0] equals to
		   0: then this option is ignored
		   1: then only plot atoms falling within the limits
		   given by plot_limits[1~6]
		   2: then atoms falling within the limits will be plotted
		   with the same color as the fixed atoms
		*/

			
		if(plot_limits[0]==1)
			if((_SR[i].x<plot_limits[1])||(_SR[i].x>plot_limits[2])
			   ||(_SR[i].y<plot_limits[3])||(_SR[i].y>plot_limits[4])
			   ||(_SR[i].z<plot_limits[5])||(_SR[i].z>plot_limits[6]))
			{
				continue;
			}
		if(plot_limits[0]==2)
			if((_SR[i].x<plot_limits[1])||(_SR[i].x>plot_limits[2])
			   ||(_SR[i].y<plot_limits[3])||(_SR[i].y>plot_limits[4])
			   ||(_SR[i].z<plot_limits[5])||(_SR[i].z>plot_limits[6]))
			{
				win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
					       atomradius[species[i]]/L,colors[MAXCOLORS+3],s,2);
				continue;
			}
        
		if (!plot_atom_info) s[0]=0;
		else
		{   /* when an atom is clicked */
			if(plot_atom_info==1)    /* print scaled coordinates of the atom */
				sprintf(s,"%d,%6.4f,%6.4f,%6.4f",
					i,_SR[i].x,_SR[i].y,_SR[i].z);
			else if(plot_atom_info==2) /* print real coordinates of the atom */
				sprintf(s,"%d,%6.4f,%6.4f,%6.4f",
					i,_R[i].x,_R[i].y,_R[i].z);
			else if(plot_atom_info==3) /* print color_ind, fixed, species info of the atom */
				sprintf(s,"%d,%8.6e %d %d",
//                        i,color_ind[i], fixed[i], species[i]);
					i,color_ind[i], fixed[i], nn[i]);
			else if(plot_atom_info==4) /* print force on the atom */
				sprintf(s,"%d,%6.4f,%6.4f,%6.4f",
					i,_F[i].x,_F[i].y,_F[i].z);
			else if(plot_atom_info==5) /* print group on the atom */
				sprintf(s,"%d,%6.4f,%6.4f,%6.4f,%6.4f",
					i,_SR[i].x,_SR[i].y,_SR[i].z,color_ind[i]);
			else
				
				s[0]=0;
		}

		
//		INFO("hello old atoms" << s);
        
		nw = (int)plot_color_windows[0];

// 	        if(i==11802)
// 		{

// 			int hahah=1;
//          		INFO_Printf("haha color_ind[%d]=%d, k=%d\n",i,color_ind[i],k);			
// 		}
		
		if(nw>0)
		{
			for(k=0;k<nw;k++)
			{
	
				Emin = plot_color_windows[k*3+1];
				Emax = plot_color_windows[k*3+2];
				cind = (int) plot_color_windows[k*3+3];
// 				if(color_ind[i]>10)
// 				{
// 					INFO_Printf("k =1 atom[%d], k=%d, color=%d\n",i,k,color_ind[i]);
// 				}

				
				if((color_ind[i]>=Emin) && (color_ind[i]<=Emax))
//				if((nnn[i]>=Emin) && (nnn[i]<=Emax))
				{

// 					if(k==1)
// 					{
// 						INFO_Printf("k =1 atom[%d], k=%d, color=%d\n",i,k,color_ind[i]);
// 					}
					plot_color_bar[0]=0;
					if(plot_color_bar[0]==0)
					{
//liu  						if(fixed[i]!=0)
//liu  							win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
//liu  							       atomradius[species[i]]/L,colors[6],s,2);
//liu  						else
						if(plotDisp==0)
						{
							win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
							       atomradius[species[i]]/L,colors[cind],s,2);
							totalplotatom++;
//							INFO("click me" << s);
						}
							
						else
						{

							for(kk=0;kk<nw;kk++)
							{
	
								EEmin = plot_color_windows[kk*3+1];
								EEmax = plot_color_windows[kk*3+2];
								ccind = (int) plot_color_windows[kk*3+3];
								if((ccolor_ind[i]>=EEmin) && (ccolor_ind[i]<=EEmax))
								{
									win->DrawPointDisp(_R[i].x/L,_R[i].y/L,_R[i].z/L, _R0[i].x/L,_R0[i].y/L,_R0[i].z/L,atomradius[species[i]]/L,colors[cind],colors[ccind],s,2);									
								}


								
							}
							
							
							totalplotatom++;
//							INFO("click me" << s);
						}
					}
					else
					{ /* color atoms according to their properties given by color_ind
					     which is specified by coloraxis
					     there are two different color maps as specified by
					     plot_color_bar[0]: 1 or 2
					  */
						alpha=(color_ind[i]-plot_color_bar[1])
							/(plot_color_bar[2]-plot_color_bar[1]);
						if(plot_color_bar[0]==1)
							colormap1(alpha,&r,&g,&b);
						else colormap2(alpha,&r,&g,&b);
                        
						ce=win->AllocShortRGBColor(r,g,b);
						if(plot_atom_info==5) /* print atom color (rgb) if clicked */
							sprintf(s,"%d,%d,%d,%d,%x",i,r,g,b,ce);
						win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
							       atomradius[species[i]]/L,ce,s,2);
					}                
				}
			}
		}
		else
		{
			high=false;
			for(j=1;j<=plot_highlight_atoms[0];j++)
				if(i==plot_highlight_atoms[j])
				{
					high=true;
					break;
				}
            
			if(fixed[i])   /* plot fixed atoms */
				win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
					       atomradius[species[i]]/L,colors[MAXCOLORS+3],s,2);
			else if (high) /* plot highlight atoms */
				win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
					       atomradius[species[i]]/L,colors[MAXCOLORS+2],s,2);
            
			else if(plot_color_bar[0]!=0)
			{ /* color atoms according to their properties given by color_ind
			     which is specified by coloraxis
			     there are two different color maps as specified by
			     plot_color_bar[0]: 1 or 2
			  */
				alpha=(color_ind[i]-plot_color_bar[1])
					/(plot_color_bar[2]-plot_color_bar[1]);
				if(plot_color_bar[0]==1)
					colormap1(alpha,&r,&g,&b);
				else colormap2(alpha,&r,&g,&b);
                
				ce=win->AllocShortRGBColor(r,g,b);
				if(plot_atom_info==5) /* print atom color (rgb) if clicked */
					sprintf(s,"%d,%d,%d,%d,%x",i,r,g,b,ce);
				win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
					       atomradius[species[i]]/L,ce,s,2);
			}
			else
			{
				/* otherwise color atoms according to their species */
				ce=colors[MAXCOLORS+5+species[i]];
				if(plot_atom_info==5) /* print atom species and color code if clicked */
					sprintf(s,"%d,%d,%x",i,species[i],ce);
                
				win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
					       atomradius[species[i]]/L,ce,s,2);
			}
		}
		
// 		if(fixed[i]!=0)
// 			win->DrawPoint(_R[i].x/L,_R[i].y/L,_R[i].z/L,
// 				       atomradius[species[i]]/L,colors[6],s,2);
						
		
	}
    
	/* Draw Bonds */
	if(bondlength>1e-3)
	{
		for(i=0;i<_NP;i++)
		{
			show = 0;
			nw = (int)plot_color_windows[0];
			if(nw>0)
			{
				for(k=0;k<nw;k++)
				{
					Emin = plot_color_windows[k*3+1];
					Emax = plot_color_windows[k*3+2];
					cind = (int) plot_color_windows[k*3+3];
                    
					if((color_ind[i]>=Emin)&& (color_ind[i]<=Emax))
					{
						show = 1;
						break;
					}
				}
			}
			else
			{
				show = 1;
			}
			if(!show) continue;
            
			for(jp=0;jp<nn[i];jp++)
			{
				j=nindex[i][jp];
				if(plot_limits[0])
					if((_SR[i].x<plot_limits[1])||(_SR[i].x>plot_limits[2])
					   ||(_SR[i].y<plot_limits[3])||(_SR[i].y>plot_limits[4])
					   ||(_SR[i].z<plot_limits[5])||(_SR[i].z>plot_limits[6])
					   ||(_SR[j].x<plot_limits[1])||(_SR[j].x>plot_limits[2])
					   ||(_SR[j].y<plot_limits[3])||(_SR[j].y>plot_limits[4])
					   ||(_SR[j].z<plot_limits[5])||(_SR[j].z>plot_limits[6]))
						continue;
				r2=(_R[i]-_R[j]).norm2();
				if(r2<bondlength*bondlength)
				{
					/* only draw O-O bonds */
					/* if((species[i]!=0)||(species[j]!=0)) continue; */
					/*INFO_Printf("atom %d %d %d %d form bond\n",i, j, i%8,j%8); */
					x1=_R[i].x/L;y1=_R[i].y/L;z1=_R[i].z/L;
					x2=_R[j].x/L;y2=_R[j].y/L;z2=_R[j].z/L;
					dx=x2-x1;dy=y2-y1;dz=z2-z1;dr=sqrt(dx*dx+dy*dy+dz*dz);
					dx/=dr;dy/=dr;dz/=dr;
					win->DrawLine(x1+dx*atomradius[species[i]]/L,
						      y1+dy*atomradius[species[i]]/L,
						      z1+dz*atomradius[species[i]]/L,
						      x2-dx*atomradius[species[j]]/L,
						      y2-dy*atomradius[species[j]]/L,
						      z2-dz*atomradius[species[j]]/L,
						      colors[MAXCOLORS+1],bondradius/L,1);
				}
			}
		}
	}
#define drawsline(a,b,c,d,e,f,g,h,i) s1.set(a,b,c); s2.set(d,e,f);\
//        vr1=_H*s1; vr2=_H*s2; vr1/=2*L; vr2/=2*L;\
        win->DrawLine(vr1.x,vr1.y,vr1.z,vr2.x,vr2.y,vr2.z,g,h,i);
	int linecolor=6;
	
// 	win->DrawLine(-1,-1,-1,-1,-1, 1,colors[linecolor],0,0);
// 	win->DrawLine(-1,-1, 1,-1, 1, 1,colors[linecolor],0,0);
// 	win->DrawLine(-1, 1, 1,-1, 1,-1,colors[linecolor],0,0);
// 	win->DrawLine(-1, 1,-1,-1,-1,-1,colors[linecolor],0,0);
// 	win->DrawLine( 1,-1,-1, 1,-1, 1,colors[linecolor],0,0);
// 	win->DrawLine( 1,-1, 1, 1, 1, 1,colors[linecolor],0,0);
// 	win->DrawLine( 1, 1, 1, 1, 1,-1,colors[linecolor],0,0);
// 	win->DrawLine( 1, 1,-1, 1,-1,-1,colors[linecolor],0,0);
// 	win->DrawLine(-1,-1,-1, 1,-1,-1,colors[linecolor],0,0);
// 	win->DrawLine(-1,-1, 1, 1,-1, 1,colors[linecolor],0,0);
// 	win->DrawLine(-1, 1, 1, 1, 1, 1,colors[linecolor],0,0);
// 	win->DrawLine(-1, 1,-1, 1, 1,-1,colors[linecolor],0,0);

	double xa,xb,ya,yb,za,zb;
	xa=plot_limits[b];xb=plot_limits[2];
	ya=plot_limits[3];yb=plot_limits[4];
	za=plot_limits[5];zb=plot_limits[6];
	

	// four lines along x
	win->DrawLine(xa,ya,za,xb,ya,za,colors[linecolor],0,0);
	win->DrawLine(xa,yb,za,xb,yb,za,colors[linecolor],0,0);
	win->DrawLine(xa,yb,zb,xb,yb,zb,colors[linecolor],0,0);
	win->DrawLine(xa,ya,zb,xb,ya,zb,colors[linecolor],0,0);


	// four lines along y
	win->DrawLine(xa,ya,za,xa,yb,za,colors[linecolor],0,0);
	win->DrawLine(xb,ya,za,xb,yb,za,colors[linecolor],0,0);
	win->DrawLine(xb,ya,zb,xb,yb,zb,colors[linecolor],0,0);
	win->DrawLine(xa,ya,zb,xa,yb,zb,colors[linecolor],0,0);
	

	// four lines along z
	win->DrawLine(xa,ya,za,xa,ya,zb,colors[linecolor],0,0);
	win->DrawLine(xb,ya,za,xb,ya,zb,colors[linecolor],0,0);
	win->DrawLine(xb,yb,za,xb,yb,zb,colors[linecolor],0,0);
	win->DrawLine(xa,yb,za,xa,yb,zb,colors[linecolor],0,0);

	
	win->Unlock();
	win->Refresh();
							
	win->totaldrawpoints=totalplotatom;
	win->totaldrawlines=totalplotatom;
	
	MP_EndMasterOnly();
}




class MDFrame sim;

int main(int argc, char *argv[])
{
	sim.initvars();
	sim.parse(SCParser::getfilehandler(argc,argv));
	return 0;
}
