#include "makeDisLoop.h"

void MAKEDISLOOP::initvars()
{
	// system variables
	bindvar("input",input,DOUBLE);
	bindvar("setlog",&setlog,INT);
	bindvar("workdir",workdir,STRING);

	// model variables
	bindvar("crystalstructure",crystalstructure,STRING);
	bindvar("latticeconst",latticeconst,DOUBLE);
	bindvar("latticesize",latticesize,DOUBLE);

	// in/out put variables
	bindvar("incnfile",incnfile,STRING);
	bindvar("outcnfile",outcnfile,STRING);
	
}

int MAKEDISLOOP::exec(char *name)
{
	// system commmands
	bindcommand(name,"setenv",setenv());
	bindcommand(name,"quit",quit());

	// model commands
	bindcommand(name,"makecrystal",makecrystal());
	bindcommand(name,"makedisline",makedisline());
	bindcommand(name,"makedisloop",makedisloop());
	bindcommand(name,"writecn",writecn());
	bindcommand(name,"writelammps",writelammps());
	return -1;
		
}

void MAKEDISLOOP::setenv()
{	
  	stime=time(&rawtime);
	starttime = localtime (&rawtime);
	cout << "start simulation at  " <<  asctime (starttime) ;
}

void MAKEDISLOOP::quit()
{
  	stime=time(&rawtime);
	starttime = localtime (&rawtime);
	cout << "sayonara,daisukina..Tokyo. at " <<  asctime (starttime);
	exit(0);
}





//--------------------------
#include "lattice.h"


// make a perfect crystal
void MAKEDISLOOP::makecrystal()
{
	LatticeConst=Vector3(latticeconst);
	LatticeSize=Vector3(latticesize);
	_NP=(int)(LatticeSize.x*LatticeSize.y*LatticeSize.z);

	int i,j,k,m;
	Vector3 temp;
	for(k=0;k<(int)LatticeSize.z;k++)
		for(j=0;j<(int)LatticeSize.y;j++)
			for(i=0;i<(int)LatticeSize.x;i++)
			{
				temp.set(i,j,k);
				latticeatoms.push_back(Atom(temp,0));
			}
	BoxSize = LatticeSize;
	BoxSize*=LatticeConst;
	cout << "basicly include atoms = "<< _NP << endl;
}


void MAKEDISLOOP::makedisline()
{
	//insert one edge dislocation line with Burgers along x;
        //Dis_pos_x = Burgers, inserted half-plane x 1,  y 2, prism,z 3, basal;
        //input  = [30 2] makedisline

	double cenline;
	cenline=input[0];
	int plane;
	plane=(int)input[1]; //1x/2y/3z
	plane--;

	Vector3 temp,temp2,temp3;
	temp3.set(0.5,0,0);
	int nn=0;
	// insert one new half-plane
	for(int i=0;i<_NP;i++)
	{
		temp=latticeatoms[i].r;
		if(temp.x == cenline && temp[plane]>=0.5*LatticeSize[plane])
		{
			temp2=temp+temp3;
			latticeatoms.push_back(Atom(temp2,0));
			nn++;
		}
	}


	// relax near planes
	double rad=10;
	double lim1=cenline-rad;
	double lim2=cenline+rad;
	double dx;
	for(int i=0;i<_NP;i++)
	{
		temp=latticeatoms[i].r;
		if(temp.x>=lim1 && temp.x<=cenline &&  temp[plane]>=0.5*LatticeSize[plane])
		{
			dx=temp.x-lim1;
			dx*=(1-0.5/rad);
			latticeatoms[i].r.x=dx+lim1;
			

		}
		else if(temp.x>cenline && temp.x<=lim2 &&  temp[plane]>=0.5*LatticeSize[plane]) 
		{
			dx=lim2-temp.x;
			dx*=(1-0.5/(rad-1));
			latticeatoms[i].r.x=lim2-dx;
		}
		
	}

	// update number of atoms;
	_NP+=nn;
	cout << "insert dislocation line atoms = " << nn << endl;

	
}


void MAKEDISLOOP::makedisloop()
{
//	# loop position x y z, habit plane, burgers, and  sia 1/vac 0  loop size
//      input = [70 15 15 3 1 1 5]  makedisloop
	Vector3 cenloop=Vector3(input[0],input[1],input[2]);
	int plane,burgers,nature;
	double radius;
	plane=(int)input[3]; //1x/2y/3z
	burgers=(int)input[4];
	nature=(int)input[5];  
	radius = input[6]+0.01;
	radius*=radius;

	if(plane==1) burgers=2;
	else if(plane==2) burgers=3;
	else if(plane==3) burgers=1;
	
	
	double deltaplane = 0.1;
	Vector3 temp;
	Vector3 LatticeConst2=LatticeConst;
	LatticeConst2/=LatticeConst[0];
	double dp,dr2;

	// determine target atoms
	int npoints=0;
	for(int i=0;i<_NP;i++)
	{
		temp=latticeatoms[i].r-cenloop;
		temp*=LatticeConst2;
		if(plane==1)
			// prism plan 1
		{
			dr2=temp.x+temp.x+temp.z*temp.z;
			dp=temp.y;
		}
		else if(plane==2)
			// prism plan 2
		{
			dr2=(0.5*temp.x-0.5*sqrt(3)*temp.y)*(0.5*temp.x-0.5*sqrt(3)*temp.y)+temp.z*temp.z;
			dp=0.5*temp.y+0.5*sqrt(3)*temp.x;
		}
		else
			// prism plan 3
		{
			dr2=(0.5*temp.x+0.5*sqrt(3)*temp.y)*(0.5*temp.x+0.5*sqrt(3)*temp.y)+temp.z*temp.z;
			dp=0.5*temp.y-0.5*sqrt(3)*temp.x;
			
			
		}
		
		if(fabs(dp)<=deltaplane && dr2 <= radius)
		{
			latticeatoms[i].group=10;
			npoints++;
		}

	}

	Vector3 dnei,atomb, tempr,sia;
	if(burgers==1) dnei.set(1,0,0);
	else if(burgers==2) dnei.set(-0.5,0.5,0);
	else if(burgers==3) dnei.set(-0.5,-0.5,0);

	tempr=dnei*0.3;
	sia=dnei*0.5;
	int bindex;
	
	if(nature==1)
		// sia
	{

		
		for(int i=0;i<_NP;i++)
		{
			if(latticeatoms[i].group==10)
			{
				latticeatoms.push_back(Atom(latticeatoms[i].r+sia,0));
				atomb=latticeatoms[i].r+dnei;
				bindex=findnearatomindex(atomb);
				latticeatoms[bindex].r+=tempr;
				latticeatoms[i].r-=tempr;
				
			}
		}
		
	}
	else
		// vac
	{
		// update the positions around expected vacancy atoms
		for(int i=0;i<_NP;i++)
		{
			if(latticeatoms[i].group==10)
			{
				atomb=latticeatoms[i].r+dnei;
				bindex=findnearatomindex(atomb);
				latticeatoms[bindex].r-=tempr;

				atomb=latticeatoms[i].r-dnei;
				bindex=findnearatomindex(atomb);
				latticeatoms[bindex].r+=tempr;

			}


		}

		// remove target atoms to form vacancies;
		int m=0;
		for(int i=0;i<_NP;i++)
		{
			if(latticeatoms[i].group!=10)
			{
				
				latticeatoms[m]=latticeatoms[i];
				m++;
			}
		}
		
	}


	//update _NP;
	if(nature==1) _NP+=npoints;
	else _NP-=npoints;

	cout << "this loop include atoms = " << npoints << endl;
}


void MAKEDISLOOP::makegroup()
{
         //2: along y; 0~1 range to be group 1;
	//input = [ 2 0 1 1 ]  makegroup
	int pind;
	double range1, range2, newgroup;
	pind=(int)input[0]; //1x/2y/3z
	pind--;//0x/1y/2z
	range1=input[1];  range1-=0.0001;
	range2=input[2];  range2-=0.0001;
	
	newgroup=input[3];
	
	for(int i=0;i<_NP;i++)
	{
		if(latticeatoms[i].r[pind] >range1 && latticeatoms[i].r[pind] <range2) latticeatoms[i].group=newgroup;
		
	}

}


int MAKEDISLOOP::findnearatomindex(Vector3 curSR)
{
	// find index of the nearst atom to curSR;
	double minR2,diffR2;
	int nindex,i;
	minR2=1.0e6; 
	nindex=-1;
	Vector3 diff;

	Vector3 LatticeConst2=LatticeConst;
	LatticeConst2/=LatticeConst[0];
	
	for(i=0;i<_NP;i++)
	{
		diff=latticeatoms[i].r-curSR;
		diff*=LatticeConst2;
		diffR2=diff.norm2();
		if(diffR2<minR2)
		{
			nindex=i;
			minR2=diffR2;

		}
		
	}

	return nindex;
}


void MAKEDISLOOP::convertReal()
{
	// for each lattice point, to add some basis atoms to form one real crystal
	UnitCell my_unitcell;
	if(strcmp(crystalstructure,"hcp_wide")==0)
			my_unitcell.set(4,hcp_basis_wide);   /* wide-hcp-crystal */
	else
			my_unitcell.set(4,hcp_basis_narrow);   /* narrow-hcp-crystal */

	Vector3 temp,temp2;
	double tg;
	for(int i=0;i<_NP;i++)
	{
		temp=latticeatoms[i].r;
		tg=latticeatoms[i].group;
		for(int m=0;m<my_unitcell.n;m++)
		{
			temp2=my_unitcell.basis[m]+temp;
			temp2/=LatticeSize;
			temp2-=0.5;
			atoms.push_back(Atom(temp2,tg));
		}

	}
	_NP*=my_unitcell.n;
}


void MAKEDISLOOP::writecn()
{
	convertReal();
	cout << "write cn "<<endl;
	
	char fname[200];
	strcpy(fname,wdir);
	strcat(fname,outcnfile);
 	ofstream fp(fname,ios::out);
 	fp << _NP << endl ;
  	for(int i=0;i<_NP;i++) 	fp << atoms[i].r << "\t"  << atoms[i].group << endl;
	fp << BoxSize[0]  << "\t" << 0 << "\t" << 0 << endl;
	fp << 0 << "\t" << BoxSize[1] <<  "\t" << 0 << endl;
	fp << 0 << "\t" << 0 << "\t" << BoxSize[2] << endl;
	fp << "1 Zr" << endl;
 	fp.close();
 	cout << "save data" << endl;
}



void MAKEDISLOOP::writelammps()
{
	convertReal();
	cout << "write lammps "<<endl;
	
	char fname[200];
	strcpy(fname,wdir);
	strcat(fname,outcnfile);
 	ofstream outfile(fname,ios::out);
	outfile << "make coords.dat from tokyomd code"<<  endl;
	outfile << _NP << "\t" << "atoms" << endl;
	outfile << "1 atom types" << endl;
	outfile << 0.000000 << "\t" << BoxSize[0] << " xlo xhi" << endl;
	outfile << 0.000000 << "\t" << BoxSize[1] << " ylo yhi" << endl;
	outfile << 0.000000 << "\t" << BoxSize[2] << " zlo zhi" << endl;

	// body fatoms position and mass
	outfile <<  endl;
	outfile << "Atoms" << endl;
	outfile <<  endl;
	for(int i=0;i<_NP;i++)
		outfile << i+1 << "\t" << 1 << "\t" << (atoms[i].r[0]+0.5)*BoxSize[0] <<"\t"<< (atoms[i].r[1]+0.5)*BoxSize[1] << "\t"<< (atoms[i].r[2]+0.5)*BoxSize[2] << endl;

	outfile << endl;
	outfile << "Masses" << endl;
	outfile << endl;
	outfile << 1 << "\t\t" <<  91.224 << endl;
	outfile.close();

 	cout << "saved data finished!" << endl;
	quit();
}



class MAKEDISLOOP sim;

int main(int argc, char *argv[])
{
	sim.initvars();
	sim.parse(SCParser::getfilehandler(argc,argv));
	return 0;
}


