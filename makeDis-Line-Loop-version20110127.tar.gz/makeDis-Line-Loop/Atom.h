#ifndef ATOM_H
#define ATOM_H

#include "linalg3.h"
#include <iostream>
using namespace std;


class Atom  
{
 public:
  
  Vector3 r,v,a;
  double pot,dev,nei,group;
  
  friend inline ostream &operator << (ostream &out, const Atom &obj)   
    {  
      //      out << obj.r << "\t" << obj.group << "\t" << obj.pot << "\t" << obj.nei << "\t" << obj.dev << endl;  
            out << obj.r << "\t" << obj.group << endl;  
      return out;  
    }
  // default constructor
  Atom(){};
  Atom(const Vector3 &tr){r=tr;group=0;}
  Atom(const Vector3 &tr, const double &ga){r=tr;group=ga;}
  //  virtual ~Atom();

  
};
#endif 
