/*
  lattice.h
  by Wei Cai  caiwei@mit.edu
  Last Modified : Thu Jan  1 13:16:22 2004

  FUNCTION  :
*/

#ifndef LATTICE_H
#define LATTICE_H
    const double hcp_basis_wide[12]={0,0,0, .0,1./3.,.5, .5,.5,.0, .5,5./6.,.5};
    const double hcp_basis_narrow[12]={0,0,0, .5,1./6.,.5, .5,.5,.0, .0,2./3.,.5};
#endif // _LATTICE_H





