#ifndef MAKEDISLOOP_H
#define MAKEDISLOOP_H

#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linalg3.h"
#include "lattice.h"
#include "scparser.h"
#include "Atom.h"

#include <iostream>
#include <fstream>
#include <cmath>
#include <ctime>
#include <vector>
#include <utility>
#include <algorithm>
#include <iterator>
#include <functional>
#include <string>
#include <sstream>


using namespace std;

class MAKEDISLOOP : public SCParser
{
 public:
  /* Configuration manipulation */
  char  crystalstructure[30];     /* crystal structure for makecrystal() */
  double latticeconst[3],latticesize[3],latticeorient[9];       /* lattice size for makecrystal() */
  int _NP;
  Matrix33 LatticeOrient,_H;
  Vector3 LatticeConst, LatticeSize,BoxSize;
  double atomgroup[5];
  // atom information;
  vector<Atom> atoms,latticeatoms;

  char incnfile[200], outcnfile[200];
  int incnfiletype;

  //--------------------------------system --------------------*/
  double input[2000];                     /* general input variable in script file */
  char workdir[200],wdir[200];
  char *myhome;
  int setlog;
  ofstream logfstream;
  streambuf *outbuf;
  int setstatus,setstatusfreq;
  struct tm *starttime;
  time_t stime,ntime,rawtime;

 public:
  
  virtual int  exec(char *name);            
  virtual void initvars();
  void runcommand();        /* run shell command */    
  void setenv();
  void quit();


  MAKEDISLOOP(): setlog(0){};
  //  virtual ~MAKEDISLOOP();

  //-----------------------Functions -------------------//
  void makecrystal();    /* create perfect crystal structure */
  void setatomsgroup();      /*set atom group within one region*/
  void makedisloop();
  void makedisline();
  void convertReal();
  int findnearatomindex(Vector3);
  void makegroup();

  void writecn();
  void readcn();
  void writelammps();  
    
};

#endif //_MAKEDISLOOP_H















